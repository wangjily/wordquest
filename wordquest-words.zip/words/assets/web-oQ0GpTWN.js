import{W as n}from"./index-C6DRKa0x.js";import"./react-BVkf-6uD.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
