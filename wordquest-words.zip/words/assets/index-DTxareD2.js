const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CaXcVXpY.js","./index-C6DRKa0x.js","./react-BVkf-6uD.js","./index-DsSbcZuH.css"])))=>i.map(i=>d[i]);
import{r as e,_ as p}from"./index-C6DRKa0x.js";import"./react-BVkf-6uD.js";const i=e("App",{web:()=>p(()=>import("./web-CaXcVXpY.js"),__vite__mapDeps([0,1,2,3]),import.meta.url).then(r=>new r.AppWeb)});export{i as App};
